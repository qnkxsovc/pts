#Personality Testing System (pts)

This software may be used to for the administration of personality tests online. 

Notes:
- Template must be in static/ (could it be dangerous that this would face the public?)
WIP
- The database MUST have a pre-populated TPeople table